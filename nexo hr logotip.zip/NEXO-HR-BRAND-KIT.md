# Nexo HR — Brend Qo'llanmasi

## 1. BREND NOMI
**Nexo HR**
- Asosiy so'z belgisi: "Nexo HR — Raqamli HR Platformasi"
- Qisqartma: NHR (iqtisodiy materiallar uchun)

---

## 2. RANG PALITRASI

### Asosiy Ranglar
| Nomi | Hex | RGB | Foydalanish |
|------|-----|-----|-----|
| **Oq** | #FFFFFF | 255, 255, 255 | Fon, matn, bo'sh joy |
| **Qora** | #000000 | 0, 0, 0 | Asosiy matn, kontrastli elementlar |
| **Accent Ko'k** | #2E56E6 | 46, 86, 230 | Logo, tugmalar, oraliqtirish, linklar |

### Qo'shimcha Ranglar (Semantik)
| Nomi | Hex | Foydalanish |
|------|-----|-----|
| **Muvaffaqiyat (Yashil)** | #10B981 | Tasdiqlash, ijobiy xabarlar |
| **Ogohlantiruv (Sariq)** | #F59E0B | Ogohlantirish, e'tibor |
| **Xato (Qizil)** | #EF4444 | Xatolar, xavf |
| **Feruza** | #5CE1E6 | Urg'u, dinamikani ko'rsatish |
| **Och Kulrang** | #F3F4F6 | Fon, kartalarin asosi |
| **Quyuq Kulrang** | #374151 | Ikkinchi darajali matn |

### Rang Ishlatilish Qoidalari
- **Asosiy brend**: Ko'k + Oq kombinatsiyasi
- **Kontrastli matn**: Qora on oq, oq on ko'k
- **Fon**: Oq yoki och kulrang
- **Aksent elementlar**: Feruza chiziqlar, ko'k tugmalar
- **Dark Mode**: Qora fon, oq matn, ko'z yashaydigan ko'k

---

## 3. SHRIFTLAR

### Ustunlik Shriftlari

#### 1. **Poppins** (Headers, Sarlavhalar)
- **Oraliq**: 700 (Bold)
- **Kichik Sarlavhalar**: 600 (SemiBold)
- **O'zi**: Zamonaviy, og'ir, mustahkam
- **CDN**: `https://fonts.googleapis.com/css2?family=Poppins:wght@600;700`

#### 2. **Inter** (Body, Asosiy Matn)
- **Oraliq**: 400 (Regular)
- **Sonlar/Jadvallar**: 500 (Medium)
- **Kichik Matn**: 12px, 400 weight
- **O'zi**: O'qilishi oson, raqamlarga mos
- **CDN**: `https://fonts.googleapis.com/css2?family=Inter:wght@400;500`

### Matn O'lchamlari (Web)
| Element | O'lchami | Weight | Chiziq Balandligi |
|---------|---------|--------|---------|
| H1 (Sarlavha) | 48px | 700 | 1.2 |
| H2 (Kichik Sarlavha) | 32px | 700 | 1.3 |
| H3 (Bo'lim Sarlavhasi) | 24px | 600 | 1.4 |
| Body Text | 16px | 400 | 1.6 |
| Kichik Matn | 14px | 400 | 1.5 |
| Dugma Matni | 14px | 600 | 1.4 |

### Matn O'lchamlari (Bosma)
| Element | O'lchami | Weight |
|---------|---------|--------|
| Sarlavha | 28pt | 700 |
| Asosiy matn | 12pt | 400 |
| Pastki sarlavha | 10pt | 500 |

---

## 4. LOGO VA BREND BELGISI

### Logo Versiyalari
1. **Asosiy** (belgi + "Nexo HR" nomi)
2. **Faqat Belgi** (Ikonka / Favicon)
3. **Qora/Oq Versiyalar** (Chop etish uchun)
4. **Yotiq Versiya** (Kichik joylar uchun)

### Xavfsiz Jon (Clearspace)
- Logo atrofida kamida **20px** bo'sh joy qoldirish
- Logo asosiy o'lchamidan kam bo'lmasligi kerak: **40px**

### Rang Variatsiyalari
- ✅ Ko'k belgi + Oq matn (asosiy)
- ✅ Oq belgi + Qora matn (qora fonlarda)
- ✅ Qora belgi + Oq matn (teskarisida)
- ❌ Polnosoch ranglar bilan (brend emas)

---

## 5. MOCKUP VA BOSMA MAHSULOTLAR

### 1️⃣ VIZITKA (Business Card)
**O'lcham**: 90 × 50 mm (stандард)

**Ön Tomoni:**
```
┌─────────────────────────────────────────┐
│                                         │
│  Nexo HR Logo (20mm)                   │
│                                         │
│  Ismingiz                               │
│  Senior HR Manager                      │
│                                         │
│  📧 email@nexohr.uz                     │
│  📱 +998 (XX) XXX-XX-XX                 │
│  🌐 nexohr.uz                           │
│                                         │
└─────────────────────────────────────────┘
```

**Orqa Tomoni:**
- Oq fon
- Kompaniya ta'rifi: "Ishlab chiqarish korxonalarining HR jarayonlarini avtomatlashtiruvchi platforma"
- Ko'k aksent chiziqlar (2px)

**Rang Sxemasi**: Oq fon, qora matn, ko'z yashaydigan ko'k aksent

---

### 2️⃣ VEBSAYT ASOSIY SAHIFASI
**O'lcham**: 1920 × 1080 (Desktop), 375 × 812 (Mobile)

**Tuzilma:**
```
┌─────────────────────────────────────────┐
│ [LOGO]  Bosh | Xususiyatlar | Narxlar  │ (Ko'k fon, oq matn)
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│                                         │
│  Hero Section:                          │
│  "HR jarayonlarini boshqaringiz         │
│   Texnologiya bilan"                    │
│                                         │
│  [Bepul Sinab Ko'rish] [Demografi ko'r]│
│                                         │
│  (Och kulrang fon, qora matn)           │
│                                         │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  Xususiyatlar (3 Ustun):                │
│  - Xodim Boshqarish                     │
│  - Martaba Rivojlanishi                 │
│  - Analitika                            │
│                                         │
│  (Oq fon, ikonkalar ko'k)               │
└─────────────────────────────────────────┘
```

**Tugmalar**: 
- Asosiy: Ko'k fon, oq matn, 14px Poppins Bold
- Ikkinchi: Oq fon, ko'k chiziq, ko'k matn

---

### 3️⃣ T-SHIRT DIZAYN
**O'lcham**: A4 (210 × 297mm) chop etish uchun

**Ko'k T-Shirt (+FFFFFF matn)**
```
           ┌──────────────────┐
           │   NEXO HR        │ (Poppins Bold, 48pt)
           │ (Logo + Matn)    │ (Faqat belgi, markazda)
           │                  │ (Suitcha ustiga joylash)
           └──────────────────┘
           
           Pastda: "Raqamli HR Platformasi" (28pt, Poppins)
```

**Rang Kombinatsiyalari:**
1. Ko'k T-shirt, oq print
2. Qora T-shirt, oq + feruza print
3. Oq T-shirt, ko'k + qora print

**Matn Joylanishi**: Markazga, 25cm balandligi

---

### 4️⃣ INSTAGRAM POST
**O'lcham**: 1080 × 1080 px

**Shablonlar:**

**Post 1 (Missiya)**
```
┌────────────────────────────────┐
│                                │
│  [Ko'k Gradient Fon]           │
│                                │
│   "Xodimlarni boshqaringiz      │
│    qog'oz yo'qligi sarishida"   │
│                                │
│   [Nexo HR Logo]               │
│                                │
│   #DigitalHR #HRtech #Nexo     │
│                                │
└────────────────────────────────┘
```

**Post 2 (Xususiyatlar)**
```
┌────────────────────────────────┐
│  Oq Fon                        │
│                                │
│  ✅ AI Nomzod Saralash         │
│  ✅ Martaba Rivojlanishi       │
│  ✅ Real-time Analitika        │
│  ✅ Mobile Ilova               │
│                                │
│  "Biz shuningdek..."           │
│  [CTA Tugmasi]                 │
│                                │
└────────────────────────────────┘
```

**Rang**: Oq fon + ko'z yashaydigan ko'k aksent

---

### 5️⃣ EMAIL SHABLON
**O'lcham**: 600px kenglik (desktop), 100% (mobile)

**Struktura:**
```
┌─────────────────────────────────────┐
│ [Ko'k Bar] "NEXO HR"                │ (Header, ko'k #2E56E6)
├─────────────────────────────────────┤
│                                     │
│  Assalomu alaykum, [Nomi]!          │ (Poppins Bold 24px)
│                                     │
│  Keling, Nexo HR-ni bo'lajak...    │ (Inter Regular 16px)
│  [Rasm/Ikonka]                      │
│                                     │
│  ┌─────────────────────────────┐   │
│  │  [KO'K TUGMA]               │   │ (Poppins Bold 14px)
│  │  Bepul Sinab Ko'rish         │   │
│  └─────────────────────────────┘   │
│                                     │
│  © 2024 Nexo HR. Barcha huquqlar.   │ (Kichik matn 12px)
│                                     │
└─────────────────────────────────────┘
```

**Rang Sxemasi**: Oq fon, ko'k bar, qora matn

---

## 6. IKONKALAR VA GRAFIKA

### Ikonka Stili
- **Shakli**: Rounded (8px radius)
- **Chiziq**: 1.5px
- **Rang**: Ko'z yashaydigan ko'k (#2E56E6) yoki feruza (#5CE1E6)
- **O'lchami**: Web uchun 24px, 32px, 48px

### Misollar
- 📋 Xodim Boshqarish
- 🚀 Martaba Rivojlanishi
- 📊 Analitika
- 🤖 AI Saralash
- 📱 Mobile Ilova

---

## 7. BOSMA XUSUSIYATLARI

### Chop Etish Uchun Talablar
- **Fayl Formati**: PDF, CMYK
- **Dpi**: 300+ (rasmlar uchun)
- **Safda Masofasi**: 5mm
- **Rang Profi**: ISO Coated v2

### Raqamli Foydalanish
- **Fayl Formati**: SVG (vektorsiz), PNG (shaffof), JPG (web)
- **Rang**: RGB, sRGB profili
- **Minimum O'lcham**: 40px (ikonka)

---

## 8. BREND OVOZI VA TONI

### Tillari
- **Rassmi Emas**: Shunchaki professional
- **Iloji Boricha Odam Yo'naltiruvchi**: "Kompaniyani emas, xodimlarni boshqaring"
- **Aniq va Tezkor**: Qo'shimcha so'zlar yo'q

### Misol Iboralari
✅ "Xodimlarni boshqaringiz"
✅ "HR jarayonlarini oddiy qiling"
✅ "Raqamli transformatsiya"

❌ "Biz eng yaxshi HR platformasiyamiz"
❌ "Bizdagi texnologiya..."

---

## 9. BRAND QOIDALARI (❌ QILA OLMAYSIZ)

| ❌ | Sababi |
|----|--------|
| Logoni chizish yoki o'zgartirish | Brend zaiflashadi |
| Boshqa ranglarni ilova qilish | Uyg'unlashtirilmagan ko'rinish |
| Shriftlarni almashtirish | Shuning uchun 2 ta tanlandi |
| Logoni chuquq tayyorlash | Vektorsiz fayllar ishlatish |
| Ranglarni keltirish/osiqlash | Ekranda tushunarsiz bo'ladi |

---

## 10. FOYDALANUVCHI FAYLLARI

**Tayyorlaydigan AI Uchun Nusxa-Nusxa:**

```yaml
BRAND_NAME: "Nexo HR"
TAGLINE: "Raqamli HR Platformasi"

COLORS:
  PRIMARY: "#2E56E6"        # Ko'z yashaydigan ko'k
  WHITE: "#FFFFFF"
  BLACK: "#000000"
  SUCCESS: "#10B981"
  WARNING: "#F59E0B"
  ERROR: "#EF4444"
  ACCENT: "#5CE1E6"
  LIGHT_BG: "#F3F4F6"
  DARK_TEXT: "#374151"

FONTS:
  HEADERS: "Poppins, sans-serif (700)"
  BODY: "Inter, sans-serif (400)"

MOCKUPS:
  - Business_Card_90x50mm
  - Website_Homepage_1920x1080
  - TShirt_Apparel_Print
  - Instagram_Post_1080x1080
  - Email_Template_600px
```

---

## 11. FOYDALI LINKLAR

- **Shriftlar**: https://fonts.google.com (Poppins, Inter)
- **Rang Tuvallari**: https://coolors.co
- **Design Tools**: Figma, Adobe XD
- **PDF Exporter**: Figma → PDF (300 DPI)

---

**Yangilandi**: 2024  
**Brend Rahbar**: Nexo HR Marketing Jamoasi

